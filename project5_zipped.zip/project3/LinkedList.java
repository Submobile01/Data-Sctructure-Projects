package project3;

import java.util.NoSuchElementException;

/**
*A generic linked list class. 
*Does not allow null elements to be stored. 
*
*@author Yiheng Jiang
*
*/
public class LinkedList<E> {
    //define internal Node class 
    protected class Node { 
        public E data; 
        public Node next; 

        public Node (E data) {
            this.data = data;
            this.next = null; 
        }
    }

    
    protected Node head;
    protected Node tail; 
    private int size;


    /*
    * Creates an empty list object.  
    */
    public LinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    /**
    *  Adds an element 'it' at position pos, shifts elements starting at pos by
    * one position to the right (higher position values). 
    * @param it the element to be added to this list 
    * @param pos the position at which the element should be added 
    * @return true, if the list has been modified as a result of this 
    * operation, false, otherwise (in this case the function should always return true)
    * @throws NullPointerException if it == null 
    * @throws NoSuchElementException if pos < 0 or pos > size
    */
    public boolean addToPos (E it, int pos) throws NullPointerException, NoSuchElementException {
        Node cur = head;
        Node n = new Node(it);
        if(it==null) throw new NullPointerException("Null Element input");
        if(pos<0||pos>size) throw new NoSuchElementException("the position is outside of the list");

        //need to do edge cases base on size
        if(head==null){
            head = n;
            tail = n;
            size++;
            return true;
        }
        else if(pos == 0){
            n.next = cur;
            head = n;
            size++;
            return true;
        }
        else if(pos == size){
            tail.next = n;
            tail = n;
            size++;
            return true;
        }
        else{
            for(int i=1; i<pos; i++){
                cur = cur.next;
            }
            Node temp = cur;
            cur = n;
            n.next = temp;
            size++;
            return true;
        }
       

    }

    //never used in Number, but left here just for the completeness of this LL class
    //can be ignored
    /**
    *  Removes and returns an element at position pos, shifts elements starting
    *  at pos+1 by one to the left (lower position values)
    *  @param pos position from which the element should be removed 
    *  @return the element that was removed 
    *  @throws NoSuchElementException if pos < 0 or pos >= size
    */ 
    public E remove(int pos) throws NoSuchElementException{
        Node cur = head;
        Node temp = null;
        if(pos<0||pos>=size) throw new NoSuchElementException("the position is outside of the list");
        else if(size == 1){
            temp = head;
            head = null;
            tail = null;
            size = 0;
            return temp.data;
        }
        else if(pos == 0){
            temp = head;
            head = head.next;
            size--;
            return temp.data;
        }
        else{
            //lets cur points to the element at pos-1
            for(int i=1; i<pos; i++){
                cur = cur.next;
            }
            //stores the node we want to remove
            temp = cur.next;

            //points the next data field of cur to cur.next.next
            cur.next = cur.next.next;

            //move the tail reference 1 prev if removing last
            if(pos == size-1) tail = cur;

            size--;
            return temp.data;
        }
    }
    
    /**
     * the number of elements in this list
     * @return the number of elements in this list
     */
    public int size(){
        return size;
    }
    
    
    //never used in Number class, left here just for the completeness of this LL class
    //can be ignored
    /**
    * Produces string representation of this list. 
    * The string contains all elements stored in the list backwards with no space.
    * @return returns the string representation of this list 
    */
    public String toString () {
        if (head == null ) return ""; 
        String toReturn = ""; 
        Node current = head; 
        while (current != null ) {
            toReturn = current.data + toReturn; 
            current = current.next;
        }
        return toReturn; 
    }

}
