package project3;

import java.util.NoSuchElementException;


public class Number extends LinkedList<Integer> implements Comparable<Number> {
	
	
	/**
	 * Creates a Number object with value represented 
	 * by the string argument number. 
	 * The number should consist of decimal digits only.
	 * @param number string representation of a number
	 * @throws NullPointerException if input String is null
	 * @throws IllegalArgumentException if number contains any illegal characters
	 */
	public Number(String number) throws NullPointerException, IllegalArgumentException{
		super();
		if(number == null) throw new NullPointerException("Null value inputed.");
		if(number.length() != 1 && number.charAt(0) == '0') 
			throw new IllegalArgumentException("Invalid Number format. Valid Number would " 
					+ "have a positive length and contain no 0 in the front unless the number is 0.");
		
		for(char c: number.toCharArray()) {
			if(!Character.isDigit(c)) throw new IllegalArgumentException("Contains invalid character that "
					+ "is not a digit. Valid digit should be 0-9");
			
			/*
			 * IllegalArgumentException won't happen because we already confirmed that each char is a digit
			 * NullPointerException won't happen because c-48 is an int, a primitive type
			 * NoSuchElementException won't happen because we are always adding to the 0th index
			 */
			this.addDigitToPos(c-48, 0);
		}
	}
	
	
	/**
	 * Computes the sum of this object with other.
	 * Returns the result in a new object. 
	 * This object is not modified by call to add.
	 * @param other the value to be added to this object
	 * @return a Number object whose value is equal to the sum of this object and other
	 * @throws NullPointerException if other is null
	 */
	public Number add(Number other) throws NullPointerException{
		if(other == null) throw new NullPointerException("Null parameter input.");
		Node thisCur = this.head;
		Node otherCur = other.head;
		Number result = new Number("0");
		int toAdd = 0;
		boolean isFirstDigit = true;
		
		while(thisCur != null || otherCur != null || (toAdd != 0)) {
			int digit = 0;
			
			//contribute to the result digit if not null
			if(thisCur != null) {
				digit += thisCur.data;
				thisCur = thisCur.next;
			}
			if(otherCur != null) {
				digit += otherCur.data;
				otherCur = otherCur.next;
			}
			
			//insert result Digit at end (change the digit if it's the first)
			
			if(isFirstDigit) {
				result.head.data = (digit+toAdd)%10;
				isFirstDigit = false;
			}
			else {
				/* method addToPos:
				 * IllegalArgumentException won't happen because %10 will produce
				 * single digit, and data won't be negative because both constructor 
				 * and addDigitToPos allows negative 
				 * NullPointerException won't happen because (digit+toAdd)%10 is an int, a primitive type
				 * NoSuchElementException won't happen because we are always adding to the size() index
				 */
				result.addDigitToPos((digit+toAdd)%10,result.size());
			}
			
			
			//update how much to add to next digit
			toAdd = (digit+toAdd)/10;
			
		}
		return result;
	}
	

	/**
	 * Computes the product of this object and a single digit digit. 
	 * Returns the result in a new object. 
	 * This object is not modified by call to multiplyByDigit.
	 * @param digit a single positive digit to be used for multiplication
	 * @return a Number object whose value is equal to the product of this object and digit
	 * @throws IllegalArgumentException if digit is negative or not one-digit
	 */
	public Number multiplyByDigit(int digit) throws IllegalArgumentException{
		if(digit<0 || digit>9) throw new IllegalArgumentException("Invalid negative "
				+ "or multi-digit input. Valid input should be one-digit positive number");
		Node cur = this.head;
		int toAdd = 0;
		Number result = new Number("0");

		//return 0 if multiplying by 0
		if(digit==0) return result;
		boolean isFirstDigit = true;
		while(cur!= null || (toAdd != 0)) {
			int num = 0;
			
			//contribute to the result digit if not null
			if(cur != null) {
				num = cur.data * digit;
				cur = cur.next;
			}
			
			
			//insert result Digit at end (change the digit if it's the first)
			if(isFirstDigit) {
				result.head.data = (num+toAdd)%10;
				isFirstDigit = false;
			}
			else {
				/*
				 * IllegalArgumentException won't happen because %10 will produce
				 * single digit, and data won't be negative because both constructor 
				 * and addDigitToPos allows negative 
				 * NullPointerException won't happen because (digit+toAdd)%10 is an int, a primitive type
				 * NoSuchElementException won't happen because we are always adding to the size() index
				 */
				result.addDigitToPos((num+toAdd)%10,result.size());
			}
			
			//update how much to add to next digit
			toAdd = (num+toAdd)/10;
		}
		return result;
	}
	
	/**
	 * Computes the product of this object and other. 
	 * Returns the result in a new object. 
	 * This object is not modified by call to multiply.
	 * @param other the value to be multiplied by this object
	 * @return a Number object whose value is equal to the product of this object and other
	 * @throws NullPointerException if other is null
	 */
	public Number multiply(Number other) throws NullPointerException{
		if(other == null) throw new NullPointerException("Null Number input");
		Number up,down;
		Number result = new Number("0");
		int counter = 0;
		
		//put the lesser digit Number down to trigger less method calls
		if(this.size()<other.size()) {
			down = this;
			up = other;
		}else {
			up = this;
			down = other;
		}
		
		Node cur = down.head;
		
		while(cur != null) {
			//add the result of multiplying by current digit shifted by according amount
			/*IllegalArgumentException 
			 *won't happen because constructor and addToPos won't
			 *let things other than single-digit natural num into node.data 
			 */
			result = result.add(up.multiplyByDigit(cur.data).shiftBy(counter));
			
			//increment
			counter++;
			cur = cur.next;
		}
		
		
		
		return result;
	}
	
	/**
	 * shifts a Number object by n places, so the Number
	 * becomes 10^n times the original Number
	 * @param n the input Number object being shifted
	 * @return the result that is 10^n times the original
	 */
	private Number shiftBy(int n) {
		for(int i=0; i<n; i++) {
			this.addDigitToPos(0,0);
		}
		return this;
	}
	
	/**
	 * return the number of digits in this object
	 * @return the number of digits in this object
	 */
	public int length() {
		return this.size();
	}
	
	
	/**
	 * Compares this object with other for order.
	 * Returns a negative integer if this object's value
	 * is strictly smaller than the value of other. 
	 * Returns a positive integer if this object's value 
	 * is strictly greater than the value of other. 
	 * Returns zero if two values are the same.
	 * @param other
	 * @return a negative integer, zero, 
	 * or a positive integer as this object
	 * is less than, equal to, or greater than other
	 */
	@Override
	public int compareTo(Number other) throws NullPointerException{
		if(other == null) throw new NullPointerException("parameter other is null");
		
		//more digit -> bigger
		if(this.size()>other.size()) return 1;
		else if(this.size()<other.size()) return -1;
		Node thisCur = this.head;
		Node otherCur = other.head;
		
		//iterate to compare each digit from bot to top
		while(thisCur!= null && otherCur != null) {
			
			if(thisCur.data != otherCur.data) {
				if(thisCur.data>otherCur.data) return 1;
				else return -1;
			}
			
			
			thisCur = thisCur.next;
			otherCur = otherCur.next;
		}
		
		return 0;
	}
	
	/**
	 * Determines if this object is equal to obj.
	 * Two Number objects are equal if all of their digits
	 * are the same and in the same order, 
	 * and if they have the same number of digits.
	 * In other words, if the values represented 
	 * by the two objects are the same.
	 * @param obj the object to be compared to this object
	 * @return true if two objects are equal, false otherwise
	 */
	public boolean equals(Object obj) {
		if(obj == null) return false;
		if(obj == this) return true;
		if(!(obj instanceof Number)) return false;
		return (this.compareTo((Number)obj)==0);
	}
	
	
	
	
	
	
	
	/**
	 * returns the string representation of the Number,
	 * from tail to head
	 * @return the string representation of the Number
	 */
	@Override
	public String toString() {
		if (head == null ) return ""; 
        String toReturn = ""; 
        Node current = head; 
        while (current != null ) {
            toReturn = current.data + toReturn; 
            current = current.next;
        }
        return toReturn; 
	}
	
	
	/**
    *  Adds an integer n at position pos, shifts elements starting at pos by
    * one position to the right (higher position values). 
    * @param n the Integer to be added to this list 
    * @param pos the position at which the element should be added 
    * @return true, if the list has been modified as a result of this 
    * operation, false, otherwise (in this case the function should always return true)
    * @throws NullPointerException if n == null 
    * @throws NoSuchElementException if pos < 0 or pos > size
    * @throws IllegalArgumentException if n is a negative Integer or multi-digit
    */
	private boolean addDigitToPos(Integer n, int pos) 
			throws NullPointerException, NoSuchElementException, IllegalArgumentException
	{
		if(n>9 || n<0) throw new IllegalArgumentException("negative or multi digit input");
		return super.addToPos(n, pos);
	}
	
}
