package project2;
import java.util.ArrayList;
import java.util.Collections;

/**
 * This class stores a list of Feature instances
 * that inherits everything from ArrayList<Feature> class.
 * a sub-FeatureList of Features can be gotten
 * by name, class, or state by public methods in the class.
 * 
 * @author Yiheng Jiang
 *
 */

public class FeatureList extends ArrayList<Feature> {
	public FeatureList() {
		super();
		
	}
	
	/**
	 * Search through the list of features for features 
	 * which has names containing the keyword parameter
	 * @param keyword the (part of) name of the features 
	 * @return the reference to a sub-FeatureList that contains
	 * every Feature within which has name that contains the keyword, or
	 * null if none are found.
	 */
	public FeatureList getByName ( String keyword ) throws IllegalArgumentException {
		
		if(keyword == null || keyword.equals("")) throw new IllegalArgumentException();
		FeatureList subList = new FeatureList();
		for(Feature f: this) {//compare in lowercase to ignore case
			if(f.getFeatureName().toLowerCase().contains(keyword.toLowerCase())) {
				subList.add(f);
			}
		}
		//return null instead of empty list
		if(subList.size() == 0) return null;
		Collections.sort(subList);
		return subList;
	}
	
	/**
	 * Search through the list of features for features 
	 * which has classes containing the keyword parameter
	 * @param keyword the (part of) class of the features 
	 * @return the reference to a sub-FeatureList that contains
	 * every Feature within which has class that contains the keyword, or
	 * null if none are found.
	 */
	public FeatureList getByClass ( String keyword ) throws IllegalArgumentException {
		if(keyword == null || keyword.equals("")) throw new IllegalArgumentException();
		FeatureList subList = new FeatureList();
		for(Feature f: this) {//compare in lowercase to ignore case
			if(f.getFeatureClass().toLowerCase().contains(keyword.toLowerCase())) {
				subList.add(f);
			}
		}
		//return null instead of empty list
		if(subList.size() == 0) return null;
		Collections.sort(subList);
		return subList;
	}
	
	/**
	 * Search through the list of features for features 
	 * which has state data field of location instance containing the keyword parameter
	 * @param keyword the (part of) state of the location of the features 
	 * @return the reference to a sub-FeatureList that contains
	 * every Feature within which has location instance that has state that contains the keyword, or
	 * null if none are found.
	 */
	public FeatureList getByState ( String state ) throws IllegalArgumentException {
		if(state == null || state.equals("")) throw new IllegalArgumentException();
		FeatureList subList = new FeatureList();
		for(Feature f: this) {//compare in lowercase to ignore case
			if(f.getFeatureLocation().getState().toLowerCase().contains(state.toLowerCase())) {
				subList.add(f);
			}
		}
		//return null instead of empty list
		if(subList.size() == 0) return null;
		Collections.sort(subList);
		return subList;
	}
	
	/**
	 * gets the String representation of this FeatureList Object
	 * according to the required format
	 * @return the String representation of this FeatureList Object
	 */
	@Override
	public String toString() {
		String s = "\n";
		for(Feature f: this) {
			System.out.println(f.toString() + "\n\n-----");
		}
		return s;
	}
}
