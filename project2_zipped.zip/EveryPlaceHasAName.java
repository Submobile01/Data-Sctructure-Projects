package project2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.xml.stream.events.Characters;
import java.util.ArrayList;

/**
 * This class is a program performing as a search engine of Features
 * by name, state, and/or class of the Feature desired
 * This program is user interactive
 * When the program is executed, the name of the input file containing 
 * all the info about different Features is provided as a single line command line argument.
 * The valid data in this field will be stored in a list of Feature objects
 * and will serve as a database to be searched
 * In the interactive part, user input a research query as the correct format. 
 * The program responds with printing a list of 
 * all the Features with all their information such as name, state, and location details
 * (If the information in the query can be found in the database.
 * 
 * @author Yiheng Jiang
 *
 */
public class EveryPlaceHasAName {

	public static void main(String[] args) {
		
		//check for existence of file name
		if(args.length == 0) {
			System.err.println("This program expects a file name as the argument\n");
			System.exit(1);
		}
		
		//check existence of file and readability
		File placeFile = new File(args[0]);
		if(!placeFile.exists()) {
			System.err.println("The file from entered file name does not exist\n");
			System.exit(1);
		}
		if(!placeFile.canRead()) {
			System.err.println("The file "+placeFile.getAbsolutePath() + " cannot be opened for reading");
			System.exit(1);
		}
		
		//set up scanner of file
		Scanner inPlace = null;
		
		//check if the file can be read by a scanner
		try {
			inPlace = new Scanner (placeFile ) ;
		} catch (FileNotFoundException e) {
			System.err.println("Error: the file "+placeFile.getAbsolutePath()+
											" cannot be opened for reading.\n");
			System.exit(1);
		}
		
		//set up variables
		FeatureList theList = new FeatureList();
		Scanner parseLine = null;
		String line = "";
		Feature f = null;
		
		//skip the first title line
		inPlace.nextLine();
		
		//scan line by line from the text document
		while(inPlace.hasNextLine()) {
			try {
				//set up 
				line = inPlace.nextLine();
				parseLine = new Scanner(line);
				parseLine.useDelimiter("\\|");
				
				//set up spaces to store parameters for the Feature object
				//constructor will be called after parameters are filled
				String name = "";
				String theClass = "";
				String state = "";
				String county = "";
				double lati = 0;
				double longi = 0;
				int elev = 0;
				
				/**
				 * reads the data in each of the 20 columns accordingly
				 * and stores the needed data.
				 * construct the Feature instance at i==20
				 */
				for(int i=0; i<21; i++) {
					if(i==0) {//id
						String s = parseLine.next();
						if(s.length()==0) {
							break;
						}
						try {
							Integer.parseInt(s);
						}catch(NumberFormatException e) {
							System.err.println("invalid ID");
							break;
						}
					}
					else if(i==1) {//feature name
						name = parseLine.next();
						
					}
					else if(i==2) {//class
						theClass = parseLine.next();
					}
					else if(i==3) {//state Alpha
						state = parseLine.next();
					}
					else if(i==5) {//county
						county = parseLine.next();
					}
					else if(i==9) {//latitude
						String s = parseLine.next();
						try {
							lati = Double.parseDouble(s);
						}catch(NumberFormatException e) {

						}
					}
					else if(i==10) {//longitude
						String s = parseLine.next();
						try {
							longi = Double.parseDouble(s);
						}catch(NumberFormatException e) {

						}
					}
					else if(i==16) {//elevation
						String s = parseLine.next();
						try {
							elev = Integer.parseInt(s);
						}catch(NumberFormatException e) {
							
						}
					}
					else if(i==20) {
						try {
							f = new Feature(name,theClass, new Location(state,county));
						}catch(IllegalArgumentException e) {
							
						}
						try{
							
							f.getFeatureLocation().setLongitude(longi);
							f.getFeatureLocation().setLatitude(lati);
							
						}catch(IllegalArgumentException e) {
							
						}
						
						f.getFeatureLocation().setElevation(elev);
						
						try {
							theList.add(f);
						}catch(NullPointerException e) {
							
						}
						
					}
					else if(i>16&&i<20) {
						try {
							parseLine.next();
						}catch(NoSuchElementException e){
							//skip the last few columns if not given since they are not required
						}
					}
					else {
						//skip the unneeded column data
						parseLine.next();
					}
					
				}
			}catch(NoSuchElementException e) {
				System.err.println(line);
				continue;
			}
			
		}
		
		//interactive mode: 
		
		Scanner userInput  = new Scanner (System.in ); 
		String userValue = "";
			
		do {
			System.out.println("Enter your search query:\n" );
			//get value of from the user 
			userValue = userInput.nextLine();
			if (!userValue.equalsIgnoreCase("quit")) { 
				String[] keywords = {"name", "state", "class"};
				int[] inds = {-1,-1,-1};
				String[] data = new String[3];//data of name, state, and class input
				String[] inputDiced = userValue.split(" ");
				
				//get indexes of the keywords from the splitted input
				for(int i=0; i<inputDiced.length; i++){
					String s = inputDiced[i];
					for(int j=0; j<3; j++){
						if(s.equalsIgnoreCase(keywords[j])) inds[j] = i;
					}
				}
				
				try{
					getData(data, inds, inputDiced);
				}catch(IllegalArgumentException e) {
					System.out.println("Invalid Input, please try again");
					continue;
				}
				
				FeatureList subList = theList;
				
				//select from the FeatureList of the dataset given
				try {
					subList = theList.getByName(data[0]);
					if(data[1] != null && subList != null) subList = subList.getByState(data[1]);
					if(data[2] != null && subList != null) subList = subList.getByClass(data[2]);
				}catch(IllegalArgumentException e) {
					//data[0] is required, and null inputs are checked for data[1] and data[2]
				}
				
				/**
				 * report no findings if the sublist is returned null, 
				 * or else print the string representation of the subList found
				 */
				if(subList == null) {
					System.out.println("No match found. Try again.\n\n");
				}else {
					System.out.println(subList);
				}
			}
			
		} while (!userValue.equalsIgnoreCase("quit"));     
		
		userInput.close();
	}
	
	/**
	 * gets user input in each category, assuming non-single words are entered
	 * @param data Array of Strings to store the user input in each category
	 * @param inds Array of indexes of the word "name", "state", and "class" in order in the split user input
	 * @param inputDiced Array of Strings containing the user input split by spaces 
	 * @throws IllegalArgumentException if the format of input query is invalid
	 */
	private static void getData(String[] data, int[] inds, String[] inputDiced) throws IllegalArgumentException{
		
		
		String[] subarray;//arbitrary pointer
		if(inds[0] !=0) throw new IllegalArgumentException("Invalid Input, please try again");
		
		if(inds[1] == -1) {//no "state" in user input
			if(inds[2] == -1) {//no "state", no "class"
				subarray = Arrays.copyOfRange(inputDiced, 1, inputDiced.length);
				if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
				data[0] = String.join(" ", subarray);
			}
			else {//no "state", yes "class"
				subarray = Arrays.copyOfRange(inputDiced, 1, inds[2]);
				if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
				data[0] = String.join(" ", subarray);
				subarray = Arrays.copyOfRange(inputDiced, inds[2]+1, inputDiced.length);
				if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
				data[2] = String.join(" ", subarray);
			}
		}
		else if(inds[2] == -1) {//no "class", yes "state"
			subarray = Arrays.copyOfRange(inputDiced, 1, inds[1]);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[0] = String.join(" ", subarray);
			subarray = Arrays.copyOfRange(inputDiced, inds[1]+1, inputDiced.length);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[1] = String.join(" ", subarray);
		}
		else if(inds[1]<inds[2]) {//state prior than class
			subarray = Arrays.copyOfRange(inputDiced, 1, inds[1]);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[0] = String.join(" ", subarray);
			subarray = Arrays.copyOfRange(inputDiced, inds[1]+1, inds[2]);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[1] = String.join(" ", subarray);
			subarray = Arrays.copyOfRange(inputDiced, inds[2]+1, inputDiced.length);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[2] = String.join(" ", subarray);
		}	
		else {//class prior than state
			subarray = Arrays.copyOfRange(inputDiced, 1, inds[1]);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[0] = String.join(" ", subarray);
			subarray = Arrays.copyOfRange(inputDiced, inds[2]+1, inds[1]);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[2] = String.join(" ", subarray);
			subarray = Arrays.copyOfRange(inputDiced, inds[1]+1, inputDiced.length);
			if(subarray.length == 0) throw new IllegalArgumentException("Invalid Input, please try again");
			data[1] = String.join(" ", subarray);
		}
	}

}
