package project2;

/**
 * This class is to store data about a Feature which contains
 * name, class and Location object.
 * 
 * @author Yiheng Jiang
 *
 */
public class Feature implements Comparable<Feature> {
	
	
	private String name;
	private String theClass;
	private Location loc;
	
	/**
	 * Constructs the Feature object with name, class and location object,
	 * @param name name of this feature
	 * @param theClass class(type) of this feature
	 * @param loc location reference, storing location data of this feature
	 * @throws IllegalArgumentException if any parameter is null or empty (if it is String type).
	 */
	public Feature(String name, String theClass, Location loc) throws IllegalArgumentException {
		if(name == null || name.equals("")) throw new IllegalArgumentException("empty name entered");
		this.name = name;
		if(theClass == null || theClass.equals("")) throw new IllegalArgumentException("empty class entered");
		this.theClass = theClass;
		if(loc == null) throw new IllegalArgumentException("null location entered");
		this.loc = loc;
	}
	
	/**
	 * gets the name of this feature object
	 * @return the name of this feature object
	 */
	public String getFeatureName() {
		return name;
	}
	
	/**
	 * gets the class of this feature object
	 * @return the class of this feature object
	 */
	public String getFeatureClass() {
		return theClass;
	}
	
	/**
	 * gets the location object of this feature object
	 * @return the reference to the location object
	 */
	public Location getFeatureLocation() {
		return loc;
	}
	
	/**
	 * Compares this Feature object with the specified Feature object for order.
	 * @param f the reference of the Feature object being compared to
	 * @return  a negative integer, zero, or a positive integer as this object is less than,
	 * equal to, or greater than the f Feature Object
	 * by name, the location object, and class in order.
	 */
	@Override
	public int compareTo(Feature f) {
		if(this == f) return 0;
		int compare = this.name.compareToIgnoreCase(f.name);
		if(compare!=0) return compare;
		compare = this.loc.compareTo(f.loc);
		if(compare!=0) return compare;
		compare = this.theClass.compareToIgnoreCase(f.theClass);
		return compare;
	}
	
	/**
	 * Indicates if this Feature object is "equaled to" another Object
	 * To Feature Objects are considered equal if name, class are equaled as Strings
	 * and their location objects are "equaled to" each other.
	 * @return true if they are equaled to each other, and false if not.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Feature))
			return false;
		return this.compareTo((Feature) obj)==0;
	}
	
	/**
	 * gets the String representation of this Feature Object
	 * @return the String representation of this Feature Object
	 */
	@Override
	public String toString() {
		String s = name+ ", " + theClass + "\n";
		s+=loc.toString();
		return s;
	}
}
