package project2;

/**
 * This class is to store information about a location
 * such as state, county, latitude, longitude and elevation
 * 
 * @author Yiheng Jiang
 *
 */
public class Location implements Comparable<Location> {
	
	private String state;
	private String county;
	private double latitude;
	private double longitude;
	private int elevation;
	
	/**
	 * Constructs the Location Object with state and country
	 * @param state state abbreviation (two letters) of this Location object
	 * @param county county of this Location object
	 * @throws IllegalArgumentException if any of the parameters are null
	 */
	public Location(String state, String county) throws IllegalArgumentException{
		if(state == null || county == null) throw new IllegalArgumentException("null argument of state and/or county");
		this.state = state;
		this.county = county;
		
	}
	
	/**
	 * get the Latitude of this Location object
	 * @return the latitude value of this Location object
	 */
	public double getLatitude() {
		return this.latitude;
	}
	
	/**
	 * sets the latitude value of the Location object with the input double value
	 * @param latitude input double value that we set the latitude class variable of this Location object to
	 * @throws IllegalArgumentException if latitude in greater than 90 or less than -90
	 */
	public void setLatitude( double latitude ) throws IllegalArgumentException {
		if(latitude>90 || latitude<-90) throw new IllegalArgumentException("Invalid latitude value, must be -90<=l<=90");
		this.latitude = latitude;
	}
	
	/**
	 * get the Longitude of this Location object
	 * @return the longitude value of this Location object
	 */
	public double getLongitude() {
		return this.longitude;
	}
	
	/**
	 * sets the longitude value of the Location object with the input double value
	 * @param longitude input double value that we set the longitude class variable of this Location object to
	 * @throws IllegalArgumentException if latitude in greater than 180 or less than -180
	 */
	public void setLongitude( double longitude ) throws IllegalArgumentException{
		if(longitude>180 || longitude<-180) throw new IllegalArgumentException("Invalid longitude value, must be -180<=l<=180");
		this.longitude = longitude;
	}
	
	/**
	 * get the elevation of this Location object
	 * @return the elevation value of this Location object
	 */
	public int getElevation() {
		return this.elevation;
	}
	
	/**
	 * sets the elevation value of the Location object with the input double value
	 * @param elevation input integer value that we set the elevation class variable of this Location object to
	 */
	public void setElevation( int elevation ) {
		this.elevation = elevation;
	}
	
	/**
	 * gets the state of this Location object
	 * @return the state variable of this Location object
	 */
	public String getState() {
		return this.state;
	}
	
	/**
	 * Compares this Feature object with the specified Location object for order.
	 * @param f the reference of the Location object being compared to
	 * @return  a negative integer, zero, or a positive integer as this object is less than, 
	 * equal to, or greater than the l Location Object
	 * by state name, county name by alphabetical order, latitude, longitude by float number numerically, 
	 * and elevation by integer value numerically.
	 */
	@Override
	public int compareTo(Location l) {
		if(this == l) return 0;
		int compare;
		compare = this.state.compareToIgnoreCase(l.state);
		if(compare!=0) {
			return compare;
		}
		compare = this.county.compareToIgnoreCase(l.county);
		if(compare!=0) {
			return compare;
		}
		compare = Double.compare(latitude, l.latitude);
		if(compare!=0) {
			return compare;
		}
		compare = Double.compare(longitude, l.longitude);
		if(compare!=0) {
			return compare;
		}
		compare = Integer.compare(elevation, l.elevation);
		return compare;
	}
	
	/**
	 * Indicates if this Feature object is "equaled to" another Object
	 * To Feature Objects are considered equal if state, county are equaled as Strings
	 * and latitude, longitude are equaled as doubles, 
	 * and elevation are equaled as integer values.
	 * @return true if they are equaled to each other, and false if not.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Location))
			return false;
		return this.compareTo((Location) obj)==0;
	}
	
	/**
	 * gets the String representation of this Location object
	 * @return the String representation of this Location object
	 */
	@Override
	public String toString() {
		String s = state + ", " + county + "\n";
		s+= latitude + ", ";
		s+= longitude + ", " + elevation;
		return s;
	}
}
