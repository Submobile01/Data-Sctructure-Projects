package project4;

import java.util.Arrays;

/**
 * The Wayfinder class is used to find and output all the
 * possible paths for the given puzzle in the form of an integer array.
 * The array is given as a command line argument array and
 * each element is a string representation of the number.
 * This will also output the number of possible paths 
 * and any errors through the error stream
 * 
 * @author Yiheng Jiang
 *
 */
public class WayFinder {
	
	/**
	 * main method of the program
	 * @param args an array of numbers represented as strings
	 * which together represents the puzzle to solve. 
	 * They must be integers from 0-99 with the last to be 0 to be a valid puzzle
	 */
	public static void main(String[] args) {
		
		
		int length = args.length;
		int[] puzzle = new int[length];
		
		//parse string[] into int[]
		for(int i=0; i<length; i++) {
			try{
				puzzle[i] = Integer.parseInt(args[i]);
			}catch(NumberFormatException e) {
				//If not numbers, print error and exit
				System.err.println("Invalid input, each value must be integers 0-99");
				System.exit(1);
			}
		}
		
		//instantiate puzzle object and print the paths
		try {
			Puzzle p = new Puzzle(puzzle);
			p.FindPaths();
		}catch(IllegalArgumentException e) {//deal with constructor exceptions
			System.err.println(e.getMessage());
			System.exit(1);
		}
		
	}
	
}
