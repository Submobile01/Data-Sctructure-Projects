package project4;
import java.util.ArrayList;

/**
 * The class Puzzle is to store the puzzle in terms of an integer array
 * and provides an method to find and print all the possible paths through
 * the puzzle in the form of a string
 * 
 * @author Yiheng Jiang
 *
 */
public class Puzzle {
	
	
	int[] puzzle;
	ArrayList<String> paths = new ArrayList<String>();
	int pathCount = 0;
	String initOutput = "";
	boolean[] initStatus;
	
	/**
	 * constructs Puzzle object that stores the input integer array
	 * @param puzzle the int[] that will be stored in the object
	 * @throws IllegalArgumentException if empty array is given,
	 * last element is non-zero, or any value is out of 0-99 range.
	 */
	public Puzzle(int[] puzzle) throws IllegalArgumentException{
		if(puzzle.length == 0) throw new IllegalArgumentException("No puzzle input received");
		if(puzzle[puzzle.length-1] != 0) 
			throw new IllegalArgumentException("Invalid puzzle. "
					+ "The last value of the Puzzle must be 0.");
		this.puzzle = puzzle;
		for(int n:puzzle) {
			if(n<0 || n>99) {
				throw new IllegalArgumentException("Value(s) in puzzle out of Range of 0-99.");
			}
		}
	}
	
	/**
	 * finds the paths through the puzzle and prints out
	 * each path as well as each step of the paths. 
	 * Also prints out how many ways there are
	 * through the puzzle.
	 */
	public void FindPaths() {//wrapper
		
		
		//handle edge case of length 1.
		if(puzzle.length == 1) {
			System.out.println("[ 0 ]");
			System.out.println("There is 1 way through the puzzle.");
			return;
		}
		
		//initialize first line;
		initOutput = addToOutput("",0,'R');
		
		//initialize the been-stepped-on status for the puzzle.
		initStatus = new boolean[puzzle.length];
		initStatus[0] = true;
		
		//call the recursive function
		FindPaths(puzzle[0],initStatus,initOutput);
		printCount();
	}
	
	/**
	 * The recursive method of the findPath() method,
	 * handles all of the recursive calls that finds and
	 * prints the steps of the paths as well as the number
	 * of steps for each path.
	 * @param curPos the current position in the puzzle
	 * @param status a boolean array storing if an element has 
	 * been stepped on. (true-has been stepped on)
	 * @param output the String output that contains the String 
	 * representation of each step up to the current step navigating
	 * the puzzle, gets printed out when reaches the end
	 */
	private void FindPaths(int curPos, boolean[] status, String output) {
		//output need to be initialized as the first line
			
		
		//if reaches the last element, print the output
		if(curPos == puzzle.length-1) {
			System.out.println(output);
			pathCount++;
			return;
		}
		
		//recursive calls
		boolean hasBeen = status[curPos];
		int curNum = puzzle[curPos];
		
		if(hasBeen) {
			//if stepping on the same node again, end the path
			return;
		}
		else {
			//go left if not out of bound
			if(curPos-curNum>=0 && curPos-curNum<=puzzle.length-1) {
				FindPaths(curPos-curNum,setStatus(status, curPos),addToOutput(output,curPos,'L'));
			}
			
			//go right if not out of bound
			if(curPos+curNum>=0 && curPos+curNum<=puzzle.length-1) {
				FindPaths(curPos+curNum,setStatus(status, curPos),addToOutput(output,curPos,'R'));
			}
				
		}
			
			
	}
	
	/**
	 * returns an array that sets the element at current position to true.
	 * @param status the original status array
	 * @param curPos the current position index
	 * @return the altered array that has the element at current index to be true.
	 */
	private boolean[] setStatus(boolean[] status, int curPos) {
		boolean[] temp = status.clone();
		temp[curPos]=true;
		return temp;
	}
	
	
	//whole line, important
	/**
	 * returns an altered output that adds the line that shows the direction
	 * to go from the current position
	 * @param output the original output that contains the steps up to the previous move
	 * @param curPos the current position index
	 * @param dir the direction it currently is going to go ('R'-Right, 'L'-Left)
	 * @return an altered output that adds the line that shows the direction
	 * to go from the current position
	 */
	private String addToOutput(String output, int curPos, char dir) {
		String result = output;
		String direction = "";
		char first = '[';
		for(int i=0; i<puzzle.length; i++) {
			if(i==curPos) {
				direction = dir+"";
			}
			else {
				direction = " ";
			}
			if(i != puzzle.length-1) {
				direction+=",";
			}
			if(i!=0) {
				first = ' ';
			}
			result+=String.format("%c%2d%s", first, puzzle[i],direction);
		}
		
		result+="]\n";
		return result;
	}
	
	/**
	 * prints a string telling how many ways there are through the puzzle
	 */
	private void printCount() {
		boolean plural = false;
		if(pathCount == 0) {
			System.out.println("No way through the puzzle");
			return;
		}
		if(pathCount>1) plural = true;
		if(plural) {
			System.out.println("There are "+pathCount+" ways through the puzzle.");
		}
		else {
			System.out.println("There is "+pathCount+" way through the puzzle.");
		}
	}
}
